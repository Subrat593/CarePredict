// Assessment JavaScript for Hospital Readmission Risk Prediction System

// Initialize assessment page when DOM loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('Assessment page initialized');
    
    // Initialize form handling
    initializeAssessmentForm();
    
    // Initialize tooltips
    initializeTooltips();
});

// Initialize assessment form
function initializeAssessmentForm() {
    const form = document.getElementById('assessmentForm');
    if (!form) return;
    
    form.addEventListener('submit', handleAssessmentSubmission);
    form.addEventListener('reset', handleFormReset);
    
    // Add real-time validation
    const inputs = form.querySelectorAll('input, select');
    inputs.forEach(input => {
        input.addEventListener('change', validateField);
        input.addEventListener('blur', validateField);
    });
}

// Handle assessment form submission
function handleAssessmentSubmission(event) {
    event.preventDefault();
    
    // Show loading overlay
    showLoadingOverlay();
    
    // Collect form data
    const formData = collectFormData();
    
    // Validate form data
    if (!validateFormData(formData)) {
        hideLoadingOverlay();
        return;
    }
    
    // Simulate processing delay
    setTimeout(() => {
        // Calculate risk assessment
        const assessment = performRiskAssessment(formData);
        
        // Display results
        displayAssessmentResults(assessment);
        
        // Hide loading overlay
        hideLoadingOverlay();
        
        // Scroll to results
        document.getElementById('assessmentResults').scrollIntoView({
            behavior: 'smooth'
        });
    }, 2000);
}

// Collect form data
function collectFormData() {
    return {
        patientName: document.getElementById('patientName').value,
        age: parseInt(document.getElementById('age').value),
        gender: document.getElementById('gender').value,
        bloodType: document.getElementById('bloodType').value,
        medicalCondition: document.getElementById('medicalCondition').value,
        testResults: document.getElementById('testResults').value,
        admissionType: document.getElementById('admissionType').value,
        insuranceProvider: document.getElementById('insuranceProvider').value,
        hospital: document.getElementById('hospital').value,
        billingAmount: parseFloat(document.getElementById('billingAmount').value)
    };
}

// Validate form data
function validateFormData(data) {
    const requiredFields = [
        'patientName', 'age', 'gender', 'bloodType', 
        'medicalCondition', 'testResults', 'admissionType', 
        'insuranceProvider', 'hospital', 'billingAmount'
    ];
    
    for (let field of requiredFields) {
        if (!data[field] || data[field] === '') {
            showValidationError(`Please fill in the ${field.replace(/([A-Z])/g, ' $1').toLowerCase()} field.`);
            return false;
        }
    }
    
    if (data.age < 1 || data.age > 120) {
        showValidationError('Please enter a valid age between 1 and 120.');
        return false;
    }
    
    if (data.billingAmount < 0) {
        showValidationError('Please enter a valid billing amount.');
        return false;
    }
    
    return true;
}

// Perform risk assessment
function performRiskAssessment(patientData) {
    const riskScore = calculateRiskScore(patientData);
    const riskLevel = getRiskLevel(riskScore);
    const riskFactors = analyzeRiskFactors(patientData);
    const recommendations = generateRecommendations(patientData, riskScore);
    
    return {
        patientData,
        riskScore,
        riskLevel,
        riskFactors,
        recommendations,
        timestamp: new Date().toLocaleString()
    };
}

// Display assessment results
function displayAssessmentResults(assessment) {
    // Show results container
    const resultsContainer = document.getElementById('assessmentResults');
    resultsContainer.style.display = 'block';
    
    // Update timestamp
    document.getElementById('assessmentTimestamp').textContent = assessment.timestamp;
    
    // Update risk score
    document.getElementById('riskScoreNumber').textContent = Math.round(assessment.riskScore);
    
    // Update risk level
    const riskLevel = document.getElementById('riskLevel');
    riskLevel.textContent = assessment.riskLevel;
    riskLevel.className = `risk-badge ${assessment.riskLevel.toLowerCase().replace(' ', '-')}-risk`;
    
    // Create risk score gauge
    createRiskScoreGauge(assessment.riskScore);
    
    // Display risk factors
    displayRiskFactors(assessment.riskFactors);
    
    // Display recommendations
    displayRecommendations(assessment.recommendations);
    
    // Display patient summary
    displayPatientSummary(assessment.patientData);
}

// Create risk score gauge chart
function createRiskScoreGauge(riskScore) {
    const ctx = document.getElementById('riskScoreGauge').getContext('2d');
    
    // Clear previous chart
    Chart.getChart(ctx)?.destroy();
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [riskScore, 100 - riskScore],
                backgroundColor: [
                    riskScore > 60 ? '#dc3545' : riskScore > 30 ? '#ffc107' : '#28a745',
                    '#e9ecef'
                ],
                borderWidth: 0,
                cutout: '75%'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: false
                }
            },
            animation: {
                animateRotate: true,
                duration: 2000
            }
        }
    });
}

// Display risk factors
function displayRiskFactors(riskFactors) {
    const container = document.getElementById('riskFactorsList');
    container.innerHTML = '';
    
    riskFactors.forEach(factor => {
        const factorElement = document.createElement('div');
        factorElement.className = 'risk-factor-item';
        factorElement.innerHTML = `
            <div class="risk-factor-header">
                <span class="risk-factor-name">${factor.name}</span>
                <span class="risk-factor-impact ${factor.impact}">${factor.impact.toUpperCase()}</span>
            </div>
            <div class="risk-factor-value">${factor.value}</div>
            <div class="risk-factor-description">${factor.description}</div>
        `;
        container.appendChild(factorElement);
    });
}

// Display recommendations
function displayRecommendations(recommendations) {
    const container = document.getElementById('recommendationsList');
    container.innerHTML = '';
    
    recommendations.forEach(recommendation => {
        const recElement = document.createElement('div');
        recElement.className = 'recommendation-item';
        recElement.innerHTML = `
            <div class="recommendation-icon">
                <i class="${recommendation.icon}"></i>
            </div>
            <div class="recommendation-text">${recommendation.text}</div>
        `;
        container.appendChild(recElement);
    });
}

// Display patient summary
function displayPatientSummary(patientData) {
    const container = document.getElementById('patientSummary');
    container.innerHTML = `
        <div class="patient-info-grid">
            <div class="patient-info-item">
                <label>Patient Name:</label>
                <span>${patientData.patientName}</span>
            </div>
            <div class="patient-info-item">
                <label>Age:</label>
                <span>${patientData.age} years</span>
            </div>
            <div class="patient-info-item">
                <label>Gender:</label>
                <span>${patientData.gender}</span>
            </div>
            <div class="patient-info-item">
                <label>Blood Type:</label>
                <span>${patientData.bloodType}</span>
            </div>
            <div class="patient-info-item">
                <label>Condition:</label>
                <span>${patientData.medicalCondition}</span>
            </div>
            <div class="patient-info-item">
                <label>Hospital:</label>
                <span>${patientData.hospital}</span>
            </div>
            <div class="patient-info-item">
                <label>Insurance:</label>
                <span>${patientData.insuranceProvider}</span>
            </div>
            <div class="patient-info-item">
                <label>Treatment Cost:</label>
                <span>₹${patientData.billingAmount.toLocaleString()}</span>
            </div>
        </div>
    `;
}

// Handle form reset
function handleFormReset() {
    // Hide results
    document.getElementById('assessmentResults').style.display = 'none';
    
    // Clear any validation errors
    clearValidationErrors();
    
    // Scroll to top of form
    document.getElementById('assessmentForm').scrollIntoView({
        behavior: 'smooth'
    });
}

// Validate individual field
function validateField(event) {
    const field = event.target;
    const value = field.value.trim();
    
    // Remove existing validation styles
    field.classList.remove('is-valid', 'is-invalid');
    
    // Add validation styles
    if (value && field.checkValidity()) {
        field.classList.add('is-valid');
    } else if (field.required && !value) {
        field.classList.add('is-invalid');
    }
}

// Show validation error
function showValidationError(message) {
    // Create or update error alert
    let errorAlert = document.getElementById('validationError');
    if (!errorAlert) {
        errorAlert = document.createElement('div');
        errorAlert.id = 'validationError';
        errorAlert.className = 'alert alert-danger alert-dismissible fade show mt-3';
        errorAlert.innerHTML = `
            <strong>Validation Error:</strong> <span id="errorMessage"></span>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        document.getElementById('assessmentForm').prepend(errorAlert);
    }
    
    document.getElementById('errorMessage').textContent = message;
    errorAlert.scrollIntoView({ behavior: 'smooth' });
}

// Clear validation errors
function clearValidationErrors() {
    const errorAlert = document.getElementById('validationError');
    if (errorAlert) {
        errorAlert.remove();
    }
    
    // Clear field validation styles
    const fields = document.querySelectorAll('.is-valid, .is-invalid');
    fields.forEach(field => {
        field.classList.remove('is-valid', 'is-invalid');
    });
}

// Show loading overlay
function showLoadingOverlay() {
    document.getElementById('loadingOverlay').style.display = 'flex';
}

// Hide loading overlay
function hideLoadingOverlay() {
    document.getElementById('loadingOverlay').style.display = 'none';
}

// Initialize tooltips
function initializeTooltips() {
    // Initialize Bootstrap tooltips if available
    if (typeof bootstrap !== 'undefined') {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    }
}

// Print results function
function printResults() {
    const resultsContent = document.getElementById('assessmentResults').cloneNode(true);
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <html>
            <head>
                <title>Risk Assessment Report</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                <link rel="stylesheet" href="styles.css">
                <style>
                    body { padding: 20px; }
                    .btn { display: none; }
                </style>
            </head>
            <body>
                <h1>Hospital Readmission Risk Assessment Report</h1>
                ${resultsContent.innerHTML}
            </body>
        </html>
    `);
    printWindow.document.close();
    printWindow.print();
}

// Export to PDF function (placeholder)
function exportToPDF() {
    alert('PDF export functionality would be implemented with a library like jsPDF or similar.');
}

// Reset assessment function
function resetAssessment() {
    document.getElementById('assessmentForm').reset();
    handleFormReset();
}