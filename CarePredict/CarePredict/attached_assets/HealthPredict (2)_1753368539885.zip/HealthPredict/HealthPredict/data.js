// Healthcare Dataset Structure and Mock Data
// Based on Kaggle Healthcare Dataset (prasad22/healthcare-dataset)

const MEDICAL_CONDITIONS = [
    'Diabetes', 'Hypertension', 'Arthritis', 'Cancer', 'Asthma', 'Obesity'
];

const BLOOD_TYPES = [
    'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'
];

const INSURANCE_PROVIDERS = [
    'Star Health Insurance', 'HDFC ERGO', 'ICICI Lombard', 'Bajaj Allianz', 'New India Assurance',
    'Oriental Insurance', 'United India Insurance', 'National Insurance', 'IFFCO Tokio', 'Religare Health'
];

const ADMISSION_TYPES = [
    'Emergency', 'Elective', 'Urgent'
];

const TEST_RESULTS = [
    'Normal', 'Abnormal', 'Inconclusive'
];

const HOSPITALS = [
    'Apollo Hospital', 'Fortis Healthcare', 'Max Super Speciality Hospital', 
    'Manipal Hospital', 'Narayana Health', 'Medanta - The Medicity',
    'Kokilaben Dhirubhai Ambani Hospital', 'Sir Ganga Ram Hospital', 'AIIMS Delhi', 'Christian Medical College'
];

const DOCTORS = [
    'Dr. Ravi Sharma', 'Dr. Priya Patel', 'Dr. Arjun Singh', 'Dr. Sunita Gupta',
    'Dr. Vikram Reddy', 'Dr. Meera Nair', 'Dr. Rajesh Kumar', 'Dr. Kavya Jain',
    'Dr. Amit Verma', 'Dr. Sneha Agarwal', 'Dr. Suresh Yadav', 'Dr. Pooja Mishra',
    'Dr. Deepak Tiwari', 'Dr. Anita Rao', 'Dr. Manoj Pandey', 'Dr. Shweta Khanna'
];

// Risk factor weights for calculation
const RISK_WEIGHTS = {
    age: 0.20,
    medicalCondition: 0.25,
    testResults: 0.30,
    admissionType: 0.15,
    billingAmount: 0.10
};

// Risk scores for different conditions
const CONDITION_RISK_SCORES = {
    'Diabetes': 75,
    'Hypertension': 65,
    'Cancer': 85,
    'Arthritis': 45,
    'Asthma': 55,
    'Obesity': 70
};

const TEST_RESULT_SCORES = {
    'Normal': 20,
    'Abnormal': 80,
    'Inconclusive': 60
};

const ADMISSION_TYPE_SCORES = {
    'Emergency': 80,
    'Urgent': 65,
    'Elective': 30
};

// Generate sample patient data for demonstrations
function generateSamplePatients(count = 50) {
    const patients = [];
    const names = [
        'Arjun Sharma', 'Priya Patel', 'Rajesh Kumar', 'Sunita Singh', 'Amit Gupta',
        'Kavya Reddy', 'Vikram Yadav', 'Sneha Jain', 'Rohit Agarwal', 'Meera Nair',
        'Suresh Verma', 'Pooja Mishra', 'Ravi Tiwari', 'Anita Rao', 'Deepak Pandey',
        'Shweta Khanna', 'Manoj Sinha', 'Rekha Bhatt', 'Karan Malhotra', 'Nisha Kapoor',
        'Ashok Dubey', 'Geeta Saxena', 'Sanjay Joshi', 'Urmila Chandra', 'Vinod Thakur',
        'Renu Bansal', 'Anil Chopra', 'Sudha Goyal', 'Harish Goel', 'Lakshmi Iyer',
        'Nitin Aggarwal', 'Savita Bhatia', 'Ramesh Mittal', 'Usha Tandon', 'Ajay Singhal',
        'Mamta Arora', 'Sunil Khurana', 'Vandana Sethi', 'Pankaj Rastogi', 'Seema Dixit',
        'Yogesh Mehta', 'Kavita Saini', 'Devendra Sharma', 'Shobha Gupta', 'Mukesh Jain',
        'Rashmi Singh', 'Anand Kumar', 'Sushma Patel', 'Girish Reddy', 'Bharti Yadav'
    ];

    for (let i = 0; i < count; i++) {
        const age = Math.floor(Math.random() * 70) + 20; // Age 20-90
        const condition = MEDICAL_CONDITIONS[Math.floor(Math.random() * MEDICAL_CONDITIONS.length)];
        const testResult = TEST_RESULTS[Math.floor(Math.random() * TEST_RESULTS.length)];
        const admissionType = ADMISSION_TYPES[Math.floor(Math.random() * ADMISSION_TYPES.length)];
        const billingAmount = Math.floor(Math.random() * 50000) + 1000; // $1,000 - $51,000

        const riskScore = calculateRiskScore({
            age,
            medicalCondition: condition,
            testResults: testResult,
            admissionType,
            billingAmount
        });

        patients.push({
            id: i + 1,
            name: names[i % names.length],
            age,
            gender: Math.random() > 0.5 ? 'Male' : 'Female',
            bloodType: BLOOD_TYPES[Math.floor(Math.random() * BLOOD_TYPES.length)],
            medicalCondition: condition,
            testResults: testResult,
            admissionType,
            hospital: HOSPITALS[Math.floor(Math.random() * HOSPITALS.length)],
            doctor: DOCTORS[Math.floor(Math.random() * DOCTORS.length)],
            insuranceProvider: INSURANCE_PROVIDERS[Math.floor(Math.random() * INSURANCE_PROVIDERS.length)],
            billingAmount,
            riskScore,
            riskLevel: getRiskLevel(riskScore),
            admissionDate: generateRandomDate(new Date(2023, 0, 1), new Date()),
            dischargeDate: null
        });
    }
    
    return patients;
}

// Calculate risk score based on patient data
function calculateRiskScore(patientData) {
    let totalScore = 0;

    // Age factor (higher age = higher risk)
    const ageScore = Math.min((patientData.age / 90) * 100, 100);
    totalScore += ageScore * RISK_WEIGHTS.age;

    // Medical condition factor
    const conditionScore = CONDITION_RISK_SCORES[patientData.medicalCondition] || 50;
    totalScore += conditionScore * RISK_WEIGHTS.medicalCondition;

    // Test results factor
    const testScore = TEST_RESULT_SCORES[patientData.testResults] || 50;
    totalScore += testScore * RISK_WEIGHTS.testResults;

    // Admission type factor
    const admissionScore = ADMISSION_TYPE_SCORES[patientData.admissionType] || 50;
    totalScore += admissionScore * RISK_WEIGHTS.admissionType;

    // Billing amount factor (higher billing = higher complexity = higher risk)
    const billingScore = Math.min((patientData.billingAmount / 50000) * 100, 100);
    totalScore += billingScore * RISK_WEIGHTS.billingAmount;

    return Math.round(Math.min(totalScore, 100));
}

// Get risk level based on score
function getRiskLevel(score) {
    if (score <= 30) return 'low';
    if (score <= 60) return 'moderate';
    return 'high';
}

// Generate random date between two dates
function generateRandomDate(start, end) {
    return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

// Risk factor analysis
function analyzeRiskFactors(patientData) {
    const factors = [];
    
    // Age analysis
    let ageImpact = 'low';
    if (patientData.age > 65) ageImpact = 'high';
    else if (patientData.age > 50) ageImpact = 'moderate';
    
    factors.push({
        name: 'Patient Age',
        value: `${patientData.age} years`,
        impact: ageImpact,
        description: patientData.age > 65 ? 'Advanced age increases readmission risk' : 
                    patientData.age > 50 ? 'Moderate age-related risk factor' : 'Low age-related risk'
    });

    // Medical condition analysis
    const conditionRisk = CONDITION_RISK_SCORES[patientData.medicalCondition];
    let conditionImpact = 'low';
    if (conditionRisk > 70) conditionImpact = 'high';
    else if (conditionRisk > 50) conditionImpact = 'moderate';
    
    factors.push({
        name: 'Medical Condition',
        value: patientData.medicalCondition,
        impact: conditionImpact,
        description: `${patientData.medicalCondition} contributes ${conditionImpact} risk for readmission`
    });

    // Test results analysis
    const testRisk = TEST_RESULT_SCORES[patientData.testResults];
    let testImpact = 'low';
    if (testRisk > 70) testImpact = 'high';
    else if (testRisk > 50) testImpact = 'moderate';
    
    factors.push({
        name: 'Test Results',
        value: patientData.testResults,
        impact: testImpact,
        description: `${patientData.testResults} test results indicate ${testImpact} risk level`
    });

    // Admission type analysis
    const admissionRisk = ADMISSION_TYPE_SCORES[patientData.admissionType];
    let admissionImpact = 'low';
    if (admissionRisk > 70) admissionImpact = 'high';
    else if (admissionRisk > 50) admissionImpact = 'moderate';
    
    factors.push({
        name: 'Admission Type',
        value: patientData.admissionType,
        impact: admissionImpact,
        description: `${patientData.admissionType} admissions have ${admissionImpact} readmission rates`
    });

    // Billing complexity analysis
    const billingImpact = patientData.billingAmount > 30000 ? 'high' : 
                         patientData.billingAmount > 15000 ? 'moderate' : 'low';
    
    factors.push({
        name: 'Care Complexity',
        value: `₹${patientData.billingAmount.toLocaleString()}`,
        impact: billingImpact,
        description: `Billing amount indicates ${billingImpact} complexity of care required`
    });

    return factors;
}

// Generate recommendations based on risk factors
function generateRecommendations(patientData, riskScore) {
    const recommendations = [];
    
    if (riskScore > 60) {
        recommendations.push({
            icon: 'fas fa-user-md',
            text: 'डिस्चार्ज के 48-72 घंटों के भीतर तत्काल फॉलो-अप अपॉइंटमेंट निर्धारित करें (Schedule immediate follow-up within 48-72 hours)'
        });
        recommendations.push({
            icon: 'fas fa-phone',
            text: 'डिस्चार्ज के बाद पहले सप्ताह के लिए दैनिक फोन चेक-इन लागू करें (Implement daily phone check-ins for first week)'
        });
        recommendations.push({
            icon: 'fas fa-pills',
            text: 'व्यापक दवा समाधान और पालन परामर्श करें (Conduct comprehensive medication reconciliation)'
        });
    }
    
    if (patientData.testResults === 'Abnormal') {
        recommendations.push({
            icon: 'fas fa-vials',
            text: 'Repeat laboratory tests within 5-7 days to monitor progress'
        });
    }
    
    if (patientData.medicalCondition === 'Diabetes') {
        recommendations.push({
            icon: 'fas fa-heartbeat',
            text: 'Ensure diabetes education and glucose monitoring equipment are provided'
        });
    }
    
    if (patientData.medicalCondition === 'Hypertension') {
        recommendations.push({
            icon: 'fas fa-heartbeat',
            text: 'Provide blood pressure monitoring instructions and equipment'
        });
    }
    
    if (patientData.age > 65) {
        recommendations.push({
            icon: 'fas fa-home',
            text: 'Consider home health services or family caregiver involvement'
        });
    }
    
    if (patientData.admissionType === 'Emergency') {
        recommendations.push({
            icon: 'fas fa-clipboard-list',
            text: 'Review and address underlying factors that led to emergency admission'
        });
    }

    recommendations.push({
        icon: 'fas fa-graduation-cap',
        text: 'Provide patient education materials specific to their condition'
    });

    return recommendations;
}

// Chart data generators
function generateMedicalConditionsData() {
    return {
        labels: MEDICAL_CONDITIONS,
        datasets: [{
            label: 'Patient Count',
            data: [1689, 1678, 1672, 1668, 1665, 1628], // Based on dataset proportions
            backgroundColor: [
                '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD'
            ],
            borderWidth: 2,
            borderColor: '#fff',
            hoverBorderWidth: 3,
            hoverBorderColor: '#333'
        }]
    };
}

function generateTestResultsData() {
    return {
        labels: TEST_RESULTS,
        datasets: [{
            label: 'Percentage',
            data: [67.3, 22.4, 10.3], // Normal, Abnormal, Inconclusive
            backgroundColor: ['#2ECC71', '#E74C3C', '#F39C12'],
            borderWidth: 3,
            borderColor: '#fff',
            hoverBorderWidth: 4,
            hoverBorderColor: '#333'
        }]
    };
}

function generateAdmissionTypesData() {
    return {
        labels: ADMISSION_TYPES,
        datasets: [{
            label: 'Admissions',
            data: [3420, 3340, 3240], // Emergency, Urgent, Elective
            backgroundColor: ['#E74C3C', '#F39C12', '#3498DB'],
            borderColor: ['#C0392B', '#E67E22', '#2980B9'],
            borderWidth: 2,
            hoverBackgroundColor: ['#F1948A', '#F8C471', '#85C1E9'],
            borderRadius: 8,
            borderSkipped: false
        }]
    };
}

function generateAgeDemographicsData() {
    return {
        labels: ['18-30', '31-45', '46-60', '61-75', '76+'],
        datasets: [{
            label: 'Patient Count',
            data: [1250, 2100, 2800, 2650, 1200],
            backgroundColor: [
                '#FF6B6B',
                '#4ECDC4', 
                '#45B7D1',
                '#96CEB4',
                '#FFEAA7'
            ],
            borderColor: [
                '#FF5252',
                '#26A69A', 
                '#2196F3',
                '#4CAF50',
                '#FFC107'
            ],
            borderWidth: 2,
            hoverBackgroundColor: [
                '#FF8A80',
                '#80CBC4', 
                '#90CAF9',
                '#C8E6C9',
                '#FFECB3'
            ],
            borderRadius: 6,
            borderSkipped: false
        }]
    };
}

function generateRiskTrendsData() {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return {
        labels: months,
        datasets: [
            {
                label: 'High Risk',
                data: [18.5, 19.2, 17.8, 16.5, 15.9, 16.8, 18.7, 19.4, 18.1, 17.6, 18.3, 19.1],
                borderColor: '#E74C3C',
                backgroundColor: 'rgba(231, 76, 60, 0.15)',
                tension: 0.4,
                borderWidth: 3,
                pointBackgroundColor: '#E74C3C',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7,
                fill: true
            },
            {
                label: 'Moderate Risk',
                data: [42.3, 41.8, 43.1, 44.2, 43.7, 42.9, 41.5, 40.8, 42.6, 43.4, 42.1, 41.9],
                borderColor: '#F39C12',
                backgroundColor: 'rgba(243, 156, 18, 0.15)',
                tension: 0.4,
                borderWidth: 3,
                pointBackgroundColor: '#F39C12',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7,
                fill: true
            },
            {
                label: 'Low Risk',
                data: [39.2, 39.0, 39.1, 39.3, 40.4, 40.3, 39.8, 39.8, 39.3, 39.0, 39.6, 39.0],
                borderColor: '#2ECC71',
                backgroundColor: 'rgba(46, 204, 113, 0.15)',
                tension: 0.4,
                borderWidth: 3,
                pointBackgroundColor: '#2ECC71',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 5,
                pointHoverRadius: 7,
                fill: true
            }
        ]
    };
}

function generateAgeRiskData() {
    return {
        labels: ['18-30', '31-45', '46-60', '61-75', '76+'],
        datasets: [
            {
                label: 'Average Risk Score',
                data: [25, 35, 48, 62, 75],
                backgroundColor: ['#2ECC71', '#3498DB', '#F39C12', '#E67E22', '#E74C3C'],
                borderColor: ['#27AE60', '#2980B9', '#E67E22', '#D35400', '#C0392B'],
                borderWidth: 2,
                hoverBackgroundColor: ['#58D68D', '#5DADE2', '#F7DC6F', '#F8C471', '#F1948A'],
                borderRadius: 8,
                borderSkipped: false
            }
        ]
    };
}

function generateInsuranceAnalysisData() {
    return {
        labels: INSURANCE_PROVIDERS.slice(0, 5), // Show top 5 providers
        datasets: [
            {
                label: 'Average Risk Score',
                data: [45, 42, 48, 46, 52], // Star Health, HDFC ERGO, ICICI Lombard, Bajaj Allianz, New India
                backgroundColor: [
                    '#FF6B6B',
                    '#4ECDC4',
                    '#45B7D1',
                    '#96CEB4',
                    '#FFEAA7'
                ],
                borderColor: [
                    '#FF5252',
                    '#26A69A',
                    '#2196F3',
                    '#4CAF50',
                    '#FFC107'
                ],
                borderWidth: 2,
                hoverBackgroundColor: [
                    '#FF8A80',
                    '#80CBC4',
                    '#90CAF9',
                    '#C8E6C9',
                    '#FFECB3'
                ],
                borderRadius: 6,
                borderSkipped: false
            }
        ]
    };
}

// Export data and functions for use in main script
window.HealthcareData = {
    MEDICAL_CONDITIONS,
    BLOOD_TYPES,
    INSURANCE_PROVIDERS,
    ADMISSION_TYPES,
    TEST_RESULTS,
    HOSPITALS,
    DOCTORS,
    generateSamplePatients,
    calculateRiskScore,
    getRiskLevel,
    analyzeRiskFactors,
    generateRecommendations,
    generateMedicalConditionsData,
    generateTestResultsData,
    generateAdmissionTypesData,
    generateAgeDemographicsData,
    generateRiskTrendsData,
    generateAgeRiskData,
    generateInsuranceAnalysisData
};
