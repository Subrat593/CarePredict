# Healthcare Readmission Risk Prediction System

## Overview

This is a multi-page frontend web application designed to predict and analyze hospital readmission risks for patients. The system provides a comprehensive dashboard with data visualization, risk assessment tools, and analytics capabilities for healthcare professionals to make informed decisions about patient care and discharge planning. The application now features Google Translate integration supporting 14 Indian languages and is structured as separate HTML pages for better organization and navigation.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

✓ Added Google Translate language translator supporting Hindi, Tamil, Telugu, Kannada, Malayalam, Gujarati, Bengali, Marathi, Punjabi, Odia, Assamese, Urdu, Sanskrit, and English (July 24, 2025)
✓ Restructured application into multiple HTML pages: index.html (home), dashboard.html, assessment.html, analytics.html, methodology.html
✓ Created dedicated JavaScript files for each page: dashboard.js, assessment.js, analytics.js
✓ Enhanced Indian localization with bilingual button text (Hindi/English)
✓ Updated all navigation to link between separate pages instead of single-page sections
✓ Added comprehensive language accessibility for all Indian users

## System Architecture

### Frontend Architecture
- **Multi-Page Application (MPA)**: Built with vanilla HTML5, CSS3, and JavaScript across separate pages
- **Responsive Design**: Uses Bootstrap 5 for mobile-first responsive layout
- **Component-Based Structure**: Modular JavaScript functions handling different aspects of each page
- **Chart Visualization**: Chart.js integration for data visualization and analytics
- **Language Translation**: Google Translate API integration for 14 Indian languages
- **Page Structure**: Separate HTML files for home, dashboard, assessment, analytics, and methodology

### UI Framework Stack
- **HTML5**: Semantic markup with accessibility considerations
- **CSS3**: Custom CSS with CSS variables for theming and Bootstrap 5 for grid system
- **JavaScript (ES6+)**: Modern JavaScript for application logic and DOM manipulation
- **Bootstrap 5**: UI components and responsive grid system
- **Font Awesome 6**: Icon library for visual elements
- **Google Fonts (Inter)**: Typography for improved readability

## Key Components

### Data Management
- **Mock Data Generator** (`data.js`): Provides realistic healthcare dataset simulation
- **Risk Calculation Engine**: Implements weighted scoring algorithm for readmission risk
- **Patient Data Structure**: Standardized patient records with medical history, demographics, and risk factors

### User Interface Components
- **Navigation Header**: Sticky navigation with page links and language translator
- **Home Page (index.html)**: Landing page with overview and navigation
- **Dashboard (dashboard.html)**: Real-time metrics and key performance indicators
- **Risk Assessment (assessment.html)**: Interactive patient evaluation form with results
- **Analytics (analytics.html)**: Comprehensive data tables and advanced visualizations
- **Methodology (methodology.html)**: Documentation of algorithms and technical implementation

### Visualization Components
- **Medical Conditions Chart**: Doughnut chart showing condition distribution
- **Risk Distribution**: Visual representation of patient risk levels
- **Interactive Data Tables**: Paginated patient listings with sorting capabilities
- **Responsive Charts**: Mobile-optimized data visualizations

## Data Flow

### Risk Calculation Process
1. **Patient Data Input**: Demographics, medical conditions, test results, admission type
2. **Weighted Scoring**: Applies predefined weights to different risk factors
3. **Risk Classification**: Categorizes patients into Low, Moderate, or High risk groups
4. **Visualization**: Displays results through charts and interactive elements

### Application Flow
1. **Initialization**: Generates sample patient data and initializes charts
2. **Data Processing**: Calculates risk scores for all patients
3. **Visualization**: Renders charts and tables with processed data
4. **User Interaction**: Handles navigation, filtering, and data exploration

## External Dependencies

### CDN Resources
- **Bootstrap 5.3.0**: UI framework and components
- **Chart.js**: Data visualization library
- **Font Awesome 6.4.0**: Icon library
- **Google Fonts (Inter)**: Web typography

### Browser Requirements
- Modern browsers supporting ES6+ JavaScript features
- CSS Grid and Flexbox support
- Canvas API for chart rendering

## Deployment Strategy

### Static Site Deployment
- **No Backend Required**: Pure frontend application suitable for static hosting
- **CDN Dependencies**: All external libraries loaded from CDNs for optimal performance
- **Browser Compatibility**: Designed for modern browsers with graceful degradation

### Hosting Options
- Static file hosting services (Netlify, Vercel, GitHub Pages)
- Traditional web hosting with static file support
- Content Delivery Networks for global distribution

### Performance Considerations
- Lazy loading for large datasets
- Responsive image optimization
- Minimal JavaScript bundle size through vanilla JS approach
- Efficient DOM manipulation and event handling

### Security Considerations
- Client-side only processing (no sensitive data transmission)
- CSP-friendly external resource loading
- XSS prevention through proper DOM manipulation practices