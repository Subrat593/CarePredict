// Hospital Readmission Risk Prediction Application
// Main JavaScript functionality

// Global variables
let charts = {};
let currentPatients = [];
let currentPage = 1;
const patientsPerPage = 10;

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApplication();
});

// Main initialization function
function initializeApplication() {
    // Generate sample patient data
    currentPatients = HealthcareData.generateSamplePatients(100);
    
    // Initialize charts
    initializeCharts();
    
    // Initialize event listeners
    initializeEventListeners();
    
    // Initialize data table
    initializeDataTable();
    
    // Animate elements on scroll
    initializeScrollAnimations();
    
    console.log('Hospital Readmission Risk Prediction System initialized');
}

// Initialize all charts
function initializeCharts() {
    // Medical Conditions Chart
    const medicalConditionsCtx = document.getElementById('medicalConditionsChart');
    if (medicalConditionsCtx) {
        charts.medicalConditions = new Chart(medicalConditionsCtx, {
            type: 'doughnut',
            data: HealthcareData.generateMedicalConditionsData(),
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    animateRotate: true,
                    animateScale: true,
                    duration: 2000,
                    easing: 'easeInOutQuart'
                },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            font: {
                                size: 12,
                                weight: '500'
                            }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#fff',
                        borderWidth: 1,
                        cornerRadius: 8,
                        displayColors: true,
                        callbacks: {
                            label: function(context) {
                                const label = context.label || '';
                                const value = context.parsed;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: ${value} patients (${percentage}%)`;
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'nearest'
                }
            }
        });
    }

    // Test Results Chart
    const testResultsCtx = document.getElementById('testResultsChart');
    if (testResultsCtx) {
        charts.testResults = new Chart(testResultsCtx, {
            type: 'pie',
            data: HealthcareData.generateTestResultsData(),
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    animateRotate: true,
                    animateScale: true,
                    duration: 1800,
                    easing: 'easeInOutQuart'
                },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            font: {
                                size: 12,
                                weight: '500'
                            }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#fff',
                        borderWidth: 1,
                        cornerRadius: 8,
                        displayColors: true,
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed}%`;
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'nearest'
                }
            }
        });
    }

    // Admission Types Chart
    const admissionTypesCtx = document.getElementById('admissionTypesChart');
    if (admissionTypesCtx) {
        charts.admissionTypes = new Chart(admissionTypesCtx, {
            type: 'bar',
            data: HealthcareData.generateAdmissionTypesData(),
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 2000,
                    easing: 'easeInOutBounce'
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 500,
                            font: {
                                size: 11
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            font: {
                                size: 11,
                                weight: '500'
                            }
                        },
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#fff',
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                return `${context.label}: ${context.parsed.y} admissions`;
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }

    // Age Demographics Chart
    const ageDemographicsCtx = document.getElementById('ageDemographicsChart');
    if (ageDemographicsCtx) {
        charts.ageDemographics = new Chart(ageDemographicsCtx, {
            type: 'bar',
            data: HealthcareData.generateAgeDemographicsData(),
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 2000,
                    easing: 'easeInOutBounce'
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            stepSize: 500,
                            font: {
                                size: 11
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            font: {
                                size: 11,
                                weight: '500'
                            }
                        },
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#fff',
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                return `Age ${context.label}: ${context.parsed.y} patients`;
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }

    // Risk Trends Chart
    const riskTrendsCtx = document.getElementById('riskTrendsChart');
    if (riskTrendsCtx) {
        charts.riskTrends = new Chart(riskTrendsCtx, {
            type: 'line',
            data: HealthcareData.generateRiskTrendsData(),
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 2500,
                    easing: 'easeInOutCubic'
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            },
                            font: {
                                size: 11
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            font: {
                                size: 11
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            font: {
                                size: 12,
                                weight: '500'
                            }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#fff',
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                return `${context.dataset.label}: ${context.parsed.y}%`;
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                elements: {
                    point: {
                        hoverRadius: 8
                    }
                }
            }
        });
    }

    // Age Risk Chart
    const ageRiskCtx = document.getElementById('ageRiskChart');
    if (ageRiskCtx) {
        charts.ageRisk = new Chart(ageRiskCtx, {
            type: 'bar',
            data: HealthcareData.generateAgeRiskData(),
            options: {
                responsive: true,
                maintainAspectRatio: false,
                animation: {
                    duration: 2000,
                    easing: 'easeInOutBounce'
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            },
                            font: {
                                size: 11
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            font: {
                                size: 11,
                                weight: '500'
                            }
                        },
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#fff',
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                return `Average Risk: ${context.parsed.y}%`;
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }

    // Insurance Analysis Chart
    const insuranceAnalysisCtx = document.getElementById('insuranceAnalysisChart');
    if (insuranceAnalysisCtx) {
        charts.insuranceAnalysis = new Chart(insuranceAnalysisCtx, {
            type: 'bar',
            data: HealthcareData.generateInsuranceAnalysisData(),
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                animation: {
                    duration: 2000,
                    easing: 'easeInOutBounce'
                },
                scales: {
                    x: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            },
                            font: {
                                size: 11
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    y: {
                        ticks: {
                            font: {
                                size: 10,
                                weight: '500'
                            }
                        },
                        grid: {
                            display: false
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleColor: '#fff',
                        bodyColor: '#fff',
                        borderColor: '#fff',
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            label: function(context) {
                                return `Average Risk: ${context.parsed.x}%`;
                            }
                        }
                    }
                },
                interaction: {
                    intersect: false,
                    mode: 'index'
                }
            }
        });
    }
}

// Initialize event listeners
function initializeEventListeners() {
    // Assessment form submission
    const assessmentForm = document.getElementById('assessmentForm');
    if (assessmentForm) {
        assessmentForm.addEventListener('submit', handleAssessmentSubmission);
    }

    // Search functionality
    const searchInput = document.getElementById('searchPatients');
    if (searchInput) {
        searchInput.addEventListener('input', handlePatientSearch);
    }

    // Chart controls
    const chartControls = document.querySelectorAll('[data-chart]');
    chartControls.forEach(control => {
        control.addEventListener('click', handleChartToggle);
    });

    // Timeframe selector
    const timeframeSelect = document.getElementById('timeframeSelect');
    if (timeframeSelect) {
        timeframeSelect.addEventListener('change', handleTimeframeChange);
    }

    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-link[href^="#"]');
    navLinks.forEach(link => {
        link.addEventListener('click', handleSmoothScroll);
    });
}

// Handle assessment form submission
function handleAssessmentSubmission(event) {
    event.preventDefault();
    
    // Show loading overlay
    showLoadingOverlay();
    
    // Collect form data
    const formData = collectFormData();
    
    // Validate form data
    if (!validateFormData(formData)) {
        hideLoadingOverlay();
        return;
    }
    
    // Simulate processing delay
    setTimeout(() => {
        // Calculate risk score
        const riskScore = HealthcareData.calculateRiskScore(formData);
        
        // Display results
        displayAssessmentResults(formData, riskScore);
        
        // Hide loading overlay
        hideLoadingOverlay();
        
        // Scroll to results
        scrollToElement('assessmentResults');
    }, 2000);
}

// Collect form data
function collectFormData() {
    return {
        patientName: document.getElementById('patientName').value,
        age: parseInt(document.getElementById('age').value),
        gender: document.getElementById('gender').value,
        bloodType: document.getElementById('bloodType').value,
        medicalCondition: document.getElementById('medicalCondition').value,
        testResults: document.getElementById('testResults').value,
        admissionType: document.getElementById('admissionType').value,
        insuranceProvider: document.getElementById('insuranceProvider').value,
        hospital: document.getElementById('hospital').value,
        billingAmount: parseFloat(document.getElementById('billingAmount').value)
    };
}

// Validate form data
function validateFormData(data) {
    const requiredFields = [
        'patientName', 'age', 'gender', 'bloodType', 'medicalCondition',
        'testResults', 'admissionType', 'insuranceProvider', 'hospital', 'billingAmount'
    ];
    
    for (const field of requiredFields) {
        if (!data[field] && data[field] !== 0) {
            alert(`Please fill in the ${field.replace(/([A-Z])/g, ' $1').toLowerCase()} field.`);
            return false;
        }
    }
    
    if (data.age < 1 || data.age > 120) {
        alert('Please enter a valid age between 1 and 120.');
        return false;
    }
    
    if (data.billingAmount < 0) {
        alert('Please enter a valid billing amount.');
        return false;
    }
    
    return true;
}

// Display assessment results
function displayAssessmentResults(patientData, riskScore) {
    const resultsSection = document.getElementById('assessmentResults');
    const timestampElement = document.getElementById('assessmentTimestamp');
    const riskScoreElement = document.getElementById('riskScoreNumber');
    const riskLevelElement = document.getElementById('riskLevel');
    const riskFactorsList = document.getElementById('riskFactorsList');
    const recommendationsList = document.getElementById('recommendationsList');
    const patientSummary = document.getElementById('patientSummary');
    
    // Set timestamp
    timestampElement.textContent = new Date().toLocaleString();
    
    // Set risk score
    riskScoreElement.textContent = riskScore;
    
    // Set risk level
    const riskLevel = HealthcareData.getRiskLevel(riskScore);
    riskLevelElement.textContent = `${riskLevel.charAt(0).toUpperCase() + riskLevel.slice(1)} Risk`;
    riskLevelElement.className = `risk-badge ${riskLevel}`;
    
    // Create risk gauge chart
    createRiskGaugeChart(riskScore);
    
    // Analyze risk factors
    const riskFactors = HealthcareData.analyzeRiskFactors(patientData);
    displayRiskFactors(riskFactors, riskFactorsList);
    
    // Generate recommendations
    const recommendations = HealthcareData.generateRecommendations(patientData, riskScore);
    displayRecommendations(recommendations, recommendationsList);
    
    // Display patient summary
    displayPatientSummary(patientData, patientSummary);
    
    // Show results section
    resultsSection.style.display = 'block';
    resultsSection.classList.add('fade-in');
}

// Create risk gauge chart
function createRiskGaugeChart(riskScore) {
    const ctx = document.getElementById('riskScoreGauge');
    if (ctx && charts.riskGauge) {
        charts.riskGauge.destroy();
    }
    
    if (ctx) {
        charts.riskGauge = new Chart(ctx, {
            type: 'doughnut',
            data: {
                datasets: [{
                    data: [riskScore, 100 - riskScore],
                    backgroundColor: [
                        riskScore > 60 ? '#ef4444' : riskScore > 30 ? '#f59e0b' : '#10b981',
                        'rgba(255, 255, 255, 0.2)'
                    ],
                    borderWidth: 0,
                    cutout: '75%'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        enabled: false
                    }
                }
            }
        });
    }
}

// Display risk factors
function displayRiskFactors(factors, container) {
    container.innerHTML = '';
    
    factors.forEach(factor => {
        const factorElement = document.createElement('div');
        factorElement.className = 'risk-factor-item';
        factorElement.innerHTML = `
            <div class="factor-name">${factor.name}: ${factor.value}</div>
            <div class="factor-impact ${factor.impact}">${factor.impact.toUpperCase()}</div>
        `;
        container.appendChild(factorElement);
    });
}

// Display recommendations
function displayRecommendations(recommendations, container) {
    container.innerHTML = '';
    
    recommendations.forEach(recommendation => {
        const recommendationElement = document.createElement('div');
        recommendationElement.className = 'recommendation-item';
        recommendationElement.innerHTML = `
            <i class="${recommendation.icon} recommendation-icon"></i>
            <div class="recommendation-text">${recommendation.text}</div>
        `;
        container.appendChild(recommendationElement);
    });
}

// Display patient summary
function displayPatientSummary(patientData, container) {
    const summaryItems = [
        { label: 'Patient Name', value: patientData.patientName },
        { label: 'Age', value: `${patientData.age} years` },
        { label: 'Gender', value: patientData.gender },
        { label: 'Blood Type', value: patientData.bloodType },
        { label: 'Medical Condition', value: patientData.medicalCondition },
        { label: 'Insurance Provider', value: patientData.insuranceProvider },
        { label: 'Hospital', value: patientData.hospital },
        { label: 'Billing Amount', value: `$${patientData.billingAmount.toLocaleString()}` }
    ];
    
    container.innerHTML = '';
    
    summaryItems.forEach(item => {
        const summaryElement = document.createElement('div');
        summaryElement.className = 'patient-summary-item';
        summaryElement.innerHTML = `
            <div class="summary-label">${item.label}</div>
            <div class="summary-value">${item.value}</div>
        `;
        container.appendChild(summaryElement);
    });
}

// Initialize data table
function initializeDataTable() {
    displayPatientTable(currentPatients);
    updatePagination();
}

// Display patient table
function displayPatientTable(patients) {
    const tableBody = document.getElementById('patientsTableBody');
    if (!tableBody) return;
    
    const startIndex = (currentPage - 1) * patientsPerPage;
    const endIndex = Math.min(startIndex + patientsPerPage, patients.length);
    const patientsToShow = patients.slice(startIndex, endIndex);
    
    tableBody.innerHTML = '';
    
    patientsToShow.forEach(patient => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>#${patient.id.toString().padStart(4, '0')}</td>
            <td>${patient.name}</td>
            <td>${patient.age}</td>
            <td>${patient.medicalCondition}</td>
            <td>${patient.testResults}</td>
            <td><span class="risk-level-badge ${patient.riskLevel}">${patient.riskLevel}</span></td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="viewPatientDetails(${patient.id})">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Handle patient search
function handlePatientSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    const filteredPatients = currentPatients.filter(patient => 
        patient.name.toLowerCase().includes(searchTerm) ||
        patient.medicalCondition.toLowerCase().includes(searchTerm) ||
        patient.testResults.toLowerCase().includes(searchTerm)
    );
    
    currentPage = 1;
    displayPatientTable(filteredPatients);
    updatePagination(filteredPatients.length);
}

// Update pagination
function updatePagination(totalPatients = currentPatients.length) {
    const paginationContainer = document.getElementById('tablePagination');
    if (!paginationContainer) return;
    
    const totalPages = Math.ceil(totalPatients / patientsPerPage);
    paginationContainer.innerHTML = '';
    
    // Previous button
    const prevButton = document.createElement('li');
    prevButton.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
    prevButton.innerHTML = `
        <a class="page-link" href="#" onclick="changePage(${currentPage - 1})">
            <i class="fas fa-chevron-left"></i>
        </a>
    `;
    paginationContainer.appendChild(prevButton);
    
    // Page numbers
    for (let i = 1; i <= totalPages; i++) {
        const pageButton = document.createElement('li');
        pageButton.className = `page-item ${i === currentPage ? 'active' : ''}`;
        pageButton.innerHTML = `
            <a class="page-link" href="#" onclick="changePage(${i})">${i}</a>
        `;
        paginationContainer.appendChild(pageButton);
    }
    
    // Next button
    const nextButton = document.createElement('li');
    nextButton.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
    nextButton.innerHTML = `
        <a class="page-link" href="#" onclick="changePage(${currentPage + 1})">
            <i class="fas fa-chevron-right"></i>
        </a>
    `;
    paginationContainer.appendChild(nextButton);
}

// Change page
function changePage(page) {
    const totalPages = Math.ceil(currentPatients.length / patientsPerPage);
    if (page < 1 || page > totalPages) return;
    
    currentPage = page;
    displayPatientTable(currentPatients);
    updatePagination();
}

// Handle chart toggle
function handleChartToggle(event) {
    const chartType = event.target.dataset.chart;
    const buttons = event.target.parentElement.querySelectorAll('.btn');
    
    // Update button states
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Update chart based on selection
    if (chartType === 'admission-trends') {
        // Update chart with trend data
        if (charts.medicalConditions) {
            charts.medicalConditions.data = HealthcareData.generateRiskTrendsData();
            charts.medicalConditions.update();
        }
    } else {
        // Restore original chart
        if (charts.medicalConditions) {
            charts.medicalConditions.data = HealthcareData.generateMedicalConditionsData();
            charts.medicalConditions.update();
        }
    }
}

// Handle timeframe change
function handleTimeframeChange(event) {
    const timeframe = event.target.value;
    // Update risk trends chart based on selected timeframe
    // This would typically fetch new data from a server
    console.log(`Updating trends for ${timeframe} days`);
}

// Handle smooth scroll
function handleSmoothScroll(event) {
    event.preventDefault();
    const targetId = event.target.getAttribute('href').substring(1);
    scrollToElement(targetId);
}

// Utility functions
function scrollToElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
}

function scrollToSection(sectionId) {
    scrollToElement(sectionId);
}

function showLoadingOverlay() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.display = 'flex';
    }
}

function hideLoadingOverlay() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

// Initialize scroll animations
function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
            }
        });
    }, observerOptions);

    // Observe elements for animation
    const elementsToAnimate = document.querySelectorAll(
        '.metric-card, .chart-card, .assessment-card, .analytics-card'
    );
    
    elementsToAnimate.forEach(element => {
        observer.observe(element);
    });
}

// Export/download functions
function downloadReport() {
    // Generate and download PDF report
    const reportData = generateReportData();
    const reportContent = createReportHTML(reportData);
    downloadHTMLAsPDF(reportContent, 'hospital-readmission-risk-report.pdf');
    
    // Show success message
    showNotification('Risk assessment report downloaded successfully!', 'success');
}

function saveAssessment() {
    // Save assessment to local storage
    const assessmentData = getCurrentAssessmentData();
    const savedAssessments = JSON.parse(localStorage.getItem('savedAssessments') || '[]');
    savedAssessments.push(assessmentData);
    localStorage.setItem('savedAssessments', JSON.stringify(savedAssessments));
    
    // Show success message
    showNotification('Assessment saved successfully!', 'success');
}

function printReport() {
    // Open print dialog for the results section
    const resultsSection = document.getElementById('assessmentResults');
    if (resultsSection) {
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Hospital Readmission Risk Assessment Report</title>
                    <style>${getPrintStyles()}</style>
                </head>
                <body>
                    <h1>Hospital Readmission Risk Assessment Report</h1>
                    ${resultsSection.innerHTML}
                </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.print();
    }
}

function exportTableData() {
    // Export patient table data as CSV
    const csvContent = generateCSVContent(currentPatients);
    downloadCSV(csvContent, 'patient-data.csv');
    
    // Show success message
    showNotification('Patient data exported successfully!', 'success');
}

function viewPatientDetails(patientId) {
    const patient = currentPatients.find(p => p.id === patientId);
    if (patient) {
        // Display patient details in a modal or new section
        showPatientModal(patient);
    }
}

// Helper functions for export/download
function generateReportData() {
    // Generate comprehensive report data
    return {
        timestamp: new Date().toLocaleString(),
        patientData: getCurrentAssessmentData(),
        riskScore: document.getElementById('riskScoreNumber').textContent,
        riskLevel: document.getElementById('riskLevel').textContent,
        recommendations: Array.from(document.querySelectorAll('.recommendation-text')).map(el => el.textContent)
    };
}

function createReportHTML(data) {
    return `
        <div class="report-header">
            <h1>Hospital Readmission Risk Assessment Report</h1>
            <p>Generated on: ${data.timestamp}</p>
        </div>
        <div class="report-content">
            <!-- Report content would be generated here -->
        </div>
    `;
}

function getCurrentAssessmentData() {
    return {
        timestamp: new Date().toISOString(),
        patientName: document.getElementById('patientName').value,
        age: document.getElementById('age').value,
        gender: document.getElementById('gender').value,
        medicalCondition: document.getElementById('medicalCondition').value,
        riskScore: document.getElementById('riskScoreNumber').textContent
    };
}

function generateCSVContent(patients) {
    const headers = ['ID', 'Name', 'Age', 'Gender', 'Medical Condition', 'Test Results', 'Risk Level', 'Risk Score'];
    const csvRows = [headers.join(',')];
    
    patients.forEach(patient => {
        const row = [
            patient.id,
            `"${patient.name}"`,
            patient.age,
            patient.gender,
            `"${patient.medicalCondition}"`,
            patient.testResults,
            patient.riskLevel,
            patient.riskScore
        ];
        csvRows.push(row.join(','));
    });
    
    return csvRows.join('\n');
}

function downloadCSV(content, filename) {
    const blob = new Blob([content], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
}

function downloadHTMLAsPDF(content, filename) {
    // This would typically use a library like jsPDF or html2pdf
    // For now, we'll just download as HTML
    const blob = new Blob([content], { type: 'text/html' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename.replace('.pdf', '.html');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
}

function getPrintStyles() {
    return `
        body { font-family: Arial, sans-serif; margin: 20px; }
        .risk-score-card { background: #f8f9fa; padding: 20px; border-radius: 8px; }
        .risk-factor-item { display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }
        .recommendation-item { margin-bottom: 10px; }
        @media print { body { margin: 0; } }
    `;
}

function showNotification(message, type = 'info') {
    // Create and show notification toast
    const notification = document.createElement('div');
    notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
    notification.style.cssText = 'top: 20px; right: 20px; z-index: 10000; min-width: 300px;';
    notification.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 5000);
}

function showPatientModal(patient) {
    // Create and show patient details modal
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.innerHTML = `
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Patient Details: ${patient.name}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-6"><strong>Age:</strong> ${patient.age}</div>
                        <div class="col-6"><strong>Gender:</strong> ${patient.gender}</div>
                        <div class="col-6"><strong>Blood Type:</strong> ${patient.bloodType}</div>
                        <div class="col-6"><strong>Condition:</strong> ${patient.medicalCondition}</div>
                        <div class="col-6"><strong>Test Results:</strong> ${patient.testResults}</div>
                        <div class="col-6"><strong>Risk Score:</strong> ${patient.riskScore}%</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="assessPatient(${patient.id})">Assess Risk</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    const bootstrapModal = new bootstrap.Modal(modal);
    bootstrapModal.show();
    
    // Remove modal from DOM when hidden
    modal.addEventListener('hidden.bs.modal', () => {
        document.body.removeChild(modal);
    });
}

function assessPatient(patientId) {
    const patient = currentPatients.find(p => p.id === patientId);
    if (patient) {
        // Pre-fill assessment form with patient data
        document.getElementById('patientName').value = patient.name;
        document.getElementById('age').value = patient.age;
        document.getElementById('gender').value = patient.gender;
        document.getElementById('bloodType').value = patient.bloodType;
        document.getElementById('medicalCondition').value = patient.medicalCondition;
        document.getElementById('testResults').value = patient.testResults;
        document.getElementById('admissionType').value = patient.admissionType;
        document.getElementById('insuranceProvider').value = patient.insuranceProvider;
        document.getElementById('hospital').value = patient.hospital;
        document.getElementById('billingAmount').value = patient.billingAmount;
        
        // Close modal and scroll to assessment form
        const modal = bootstrap.Modal.getInstance(document.querySelector('.modal'));
        if (modal) modal.hide();
        
        scrollToSection('assessment');
    }
}

// Global functions for inline event handlers
window.scrollToSection = scrollToSection;
window.downloadReport = downloadReport;
window.saveAssessment = saveAssessment;
window.printReport = printReport;
window.exportTableData = exportTableData;
window.viewPatientDetails = viewPatientDetails;
window.changePage = changePage;
window.assessPatient = assessPatient;
