// Dashboard JavaScript for Hospital Readmission Risk Prediction System

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('Dashboard initialized');
    
    // Generate sample data for dashboard
    const sampleData = generateSampleData(10000);
    
    // Initialize all dashboard charts
    createMedicalConditionsChart(sampleData);
    createTestResultsChart(sampleData);
    createAdmissionTypesChart(sampleData);
    createAgeDemographicsChart(sampleData);
    
    // Update metrics cards
    updateMetricsCards(sampleData);
});

// Create medical conditions chart
function createMedicalConditionsChart(data) {
    const ctx = document.getElementById('medicalConditionsChart').getContext('2d');
    
    // Count conditions
    const conditionCounts = {};
    data.forEach(patient => {
        conditionCounts[patient.medicalCondition] = (conditionCounts[patient.medicalCondition] || 0) + 1;
    });
    
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: Object.keys(conditionCounts),
            datasets: [{
                data: Object.values(conditionCounts),
                backgroundColor: [
                    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', 
                    '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F'
                ],
                borderWidth: 0,
                hoverOffset: 15
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const percentage = ((context.parsed / data.length) * 100).toFixed(1);
                            return `${context.label}: ${context.parsed} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateRotate: true,
                duration: 2000
            }
        }
    });
}

// Create test results chart
function createTestResultsChart(data) {
    const ctx = document.getElementById('testResultsChart').getContext('2d');
    
    // Count test results
    const resultCounts = {
        'Normal': 0,
        'Abnormal': 0,
        'Inconclusive': 0
    };
    
    data.forEach(patient => {
        resultCounts[patient.testResults]++;
    });
    
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: Object.keys(resultCounts),
            datasets: [{
                data: Object.values(resultCounts),
                backgroundColor: ['#28a745', '#dc3545', '#ffc107'],
                borderWidth: 0,
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 15,
                        usePointStyle: true
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const percentage = ((context.parsed / data.length) * 100).toFixed(1);
                            return `${context.label}: ${context.parsed} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                duration: 1500
            }
        }
    });
}

// Create admission types chart
function createAdmissionTypesChart(data) {
    const ctx = document.getElementById('admissionTypesChart').getContext('2d');
    
    // Count admission types
    const admissionCounts = {};
    data.forEach(patient => {
        admissionCounts[patient.admissionType] = (admissionCounts[patient.admissionType] || 0) + 1;
    });
    
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(admissionCounts),
            datasets: [{
                label: 'Number of Patients',
                data: Object.values(admissionCounts),
                backgroundColor: ['#FF6B6B', '#4ECDC4', '#45B7D1'],
                borderColor: ['#FF5252', '#26A69A', '#2196F3'],
                borderWidth: 2,
                borderRadius: 8,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const percentage = ((context.parsed.y / data.length) * 100).toFixed(1);
                            return `${context.parsed.y} patients (${percentage}%)`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: '#f0f0f0'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            animation: {
                delay: (context) => context.dataIndex * 200,
                duration: 1000
            }
        }
    });
}

// Create age demographics chart
function createAgeDemographicsChart(data) {
    const ctx = document.getElementById('ageDemographicsChart').getContext('2d');
    
    // Create age groups
    const ageGroups = {
        '18-30': 0,
        '31-45': 0,
        '46-60': 0,
        '61-75': 0,
        '76+': 0
    };
    
    data.forEach(patient => {
        const age = patient.age;
        if (age <= 30) ageGroups['18-30']++;
        else if (age <= 45) ageGroups['31-45']++;
        else if (age <= 60) ageGroups['46-60']++;
        else if (age <= 75) ageGroups['61-75']++;
        else ageGroups['76+']++;
    });
    
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: Object.keys(ageGroups),
            datasets: [{
                label: 'Number of Patients',
                data: Object.values(ageGroups),
                borderColor: '#4ECDC4',
                backgroundColor: 'rgba(78, 205, 196, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#4ECDC4',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 6,
                pointHoverRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            const percentage = ((context.parsed.y / data.length) * 100).toFixed(1);
                            return `${context.parsed.y} patients (${percentage}%)`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: '#f0f0f0'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            },
            animation: {
                duration: 2000,
                easing: 'easeInOutQuart'
            }
        }
    });
}

// Update metrics cards
function updateMetricsCards(data) {
    // Calculate metrics
    const normalResults = data.filter(p => p.testResults === 'Normal').length;
    const abnormalResults = data.filter(p => p.testResults === 'Abnormal').length;
    const inconclusiveResults = data.filter(p => p.testResults === 'Inconclusive').length;
    
    // Calculate risk levels
    const highRiskPatients = data.filter(p => {
        const riskScore = calculateRiskScore(p);
        return riskScore > 60;
    }).length;
    
    // Update the metrics with animations
    animateValue('normal-percentage', 0, (normalResults / data.length * 100).toFixed(1), 2000);
    animateValue('abnormal-percentage', 0, (abnormalResults / data.length * 100).toFixed(1), 2000);
    animateValue('inconclusive-percentage', 0, (inconclusiveResults / data.length * 100).toFixed(1), 2000);
    animateValue('high-risk-percentage', 0, (highRiskPatients / data.length * 100).toFixed(1), 2000);
}

// Animate number values
function animateValue(elementId, start, end, duration) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    const startTime = performance.now();
    const startValue = parseFloat(start);
    const endValue = parseFloat(end);
    
    function updateValue(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        const currentValue = startValue + (endValue - startValue) * easeOutQuart(progress);
        element.textContent = currentValue.toFixed(1) + '%';
        
        if (progress < 1) {
            requestAnimationFrame(updateValue);
        }
    }
    
    requestAnimationFrame(updateValue);
}

// Easing function
function easeOutQuart(t) {
    return 1 - Math.pow(1 - t, 4);
}