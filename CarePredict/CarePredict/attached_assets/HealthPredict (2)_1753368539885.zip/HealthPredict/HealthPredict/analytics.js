// Analytics JavaScript for Hospital Readmission Risk Prediction System

// Global variables
let patientsData = [];
let currentPage = 1;
let itemsPerPage = 25;
let filteredData = [];

// Initialize analytics page when DOM loads
document.addEventListener('DOMContentLoaded', function() {
    console.log('Analytics page initialized');
    
    // Generate comprehensive patient data
    patientsData = generateSampleData(10000);
    filteredData = [...patientsData];
    
    // Initialize analytics components
    initializeDataTable();
    initializeFilters();
    initializeCharts();
    updateStatistics();
});

// Initialize data table
function initializeDataTable() {
    populateTable();
    setupPagination();
    
    // Add search functionality
    const searchInput = document.getElementById('patientSearch');
    if (searchInput) {
        searchInput.addEventListener('input', handleSearch);
    }
    
    // Add filter functionality
    const conditionFilter = document.getElementById('conditionFilter');
    const riskFilter = document.getElementById('riskFilter');
    
    if (conditionFilter) conditionFilter.addEventListener('change', handleFilter);
    if (riskFilter) riskFilter.addEventListener('change', handleFilter);
}

// Populate data table
function populateTable() {
    const tbody = document.getElementById('patientsTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const pageData = filteredData.slice(startIndex, endIndex);
    
    pageData.forEach((patient, index) => {
        const riskScore = calculateRiskScore(patient);
        const riskLevel = getRiskLevel(riskScore);
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>#${String(startIndex + index + 1).padStart(4, '0')}</td>
            <td>${patient.name}</td>
            <td>${patient.age}</td>
            <td>${patient.gender}</td>
            <td>${patient.medicalCondition}</td>
            <td>
                <span class="badge ${patient.testResults.toLowerCase()}-result">
                    ${patient.testResults}
                </span>
            </td>
            <td>${patient.admissionType}</td>
            <td>${patient.hospital}</td>
            <td>${patient.insuranceProvider}</td>
            <td>
                <span class="badge ${riskLevel.toLowerCase().replace(' ', '-')}-risk">
                    ${riskLevel}
                </span>
            </td>
            <td>${Math.round(riskScore)}%</td>
            <td>
                <button class="btn btn-sm btn-outline-primary" onclick="viewPatientDetails(${startIndex + index})">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="btn btn-sm btn-outline-info" onclick="generateReport(${startIndex + index})">
                    <i class="fas fa-file-alt"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Setup pagination
function setupPagination() {
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    const pagination = document.getElementById('tablePagination');
    
    if (!pagination) return;
    
    pagination.innerHTML = '';
    
    // Previous button
    const prevLi = document.createElement('li');
    prevLi.className = `page-item ${currentPage === 1 ? 'disabled' : ''}`;
    prevLi.innerHTML = `
        <a class="page-link" href="#" onclick="changePage(${currentPage - 1})">
            <i class="fas fa-chevron-left"></i>
        </a>
    `;
    pagination.appendChild(prevLi);
    
    // Page numbers
    const startPage = Math.max(1, currentPage - 2);
    const endPage = Math.min(totalPages, currentPage + 2);
    
    for (let i = startPage; i <= endPage; i++) {
        const li = document.createElement('li');
        li.className = `page-item ${i === currentPage ? 'active' : ''}`;
        li.innerHTML = `<a class="page-link" href="#" onclick="changePage(${i})">${i}</a>`;
        pagination.appendChild(li);
    }
    
    // Next button
    const nextLi = document.createElement('li');
    nextLi.className = `page-item ${currentPage === totalPages ? 'disabled' : ''}`;
    nextLi.innerHTML = `
        <a class="page-link" href="#" onclick="changePage(${currentPage + 1})">
            <i class="fas fa-chevron-right"></i>
        </a>
    `;
    pagination.appendChild(nextLi);
}

// Change page
function changePage(page) {
    const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    if (page >= 1 && page <= totalPages) {
        currentPage = page;
        populateTable();
        setupPagination();
    }
}

// Handle search
function handleSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    
    filteredData = patientsData.filter(patient => 
        patient.name.toLowerCase().includes(searchTerm) ||
        patient.medicalCondition.toLowerCase().includes(searchTerm) ||
        patient.hospital.toLowerCase().includes(searchTerm) ||
        patient.insuranceProvider.toLowerCase().includes(searchTerm)
    );
    
    currentPage = 1;
    populateTable();
    setupPagination();
    updateStatistics();
}

// Handle filters
function handleFilter() {
    const conditionFilter = document.getElementById('conditionFilter').value;
    const riskFilter = document.getElementById('riskFilter').value;
    
    filteredData = patientsData.filter(patient => {
        const matchesCondition = !conditionFilter || patient.medicalCondition === conditionFilter;
        
        let matchesRisk = true;
        if (riskFilter) {
            const riskScore = calculateRiskScore(patient);
            const riskLevel = getRiskLevel(riskScore);
            matchesRisk = riskLevel === riskFilter;
        }
        
        return matchesCondition && matchesRisk;
    });
    
    currentPage = 1;
    populateTable();
    setupPagination();
    updateStatistics();
}

// Initialize filters
function initializeFilters() {
    // Set up filter event listeners
    const filters = document.querySelectorAll('#conditionFilter, #riskFilter');
    filters.forEach(filter => {
        filter.addEventListener('change', handleFilter);
    });
}

// Initialize charts
function initializeCharts() {
    createRiskTrendsChart();
    createHospitalPerformanceChart();
    createAgeRiskCorrelationChart();
}

// Create risk trends chart
function createRiskTrendsChart() {
    const ctx = document.getElementById('riskTrendsChart');
    if (!ctx) return;
    
    // Calculate risk distribution
    const riskDistribution = {
        'Low Risk': 0,
        'Moderate Risk': 0,
        'High Risk': 0
    };
    
    patientsData.forEach(patient => {
        const riskScore = calculateRiskScore(patient);
        const riskLevel = getRiskLevel(riskScore);
        riskDistribution[riskLevel]++;
    });
    
    new Chart(ctx.getContext('2d'), {
        type: 'bar',
        data: {
            labels: Object.keys(riskDistribution),
            datasets: [{
                label: 'Number of Patients',
                data: Object.values(riskDistribution),
                backgroundColor: ['#28a745', '#ffc107', '#dc3545'],
                borderColor: ['#20c997', '#ffb340', '#dc3545'],
                borderWidth: 2,
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const percentage = ((context.parsed.y / patientsData.length) * 100).toFixed(1);
                            return `${context.parsed.y} patients (${percentage}%)`;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: '#f0f0f0'
                    }
                },
                x: {
                    grid: {
                        display: false
                    }
                }
            },
            animation: {
                duration: 1500,
                easing: 'easeInOutQuart'
            }
        }
    });
}

// Create hospital performance chart
function createHospitalPerformanceChart() {
    const ctx = document.getElementById('hospitalPerformanceChart');
    if (!ctx) return;
    
    // Calculate hospital performance (average risk score)
    const hospitalStats = {};
    
    patientsData.forEach(patient => {
        if (!hospitalStats[patient.hospital]) {
            hospitalStats[patient.hospital] = {
                totalRisk: 0,
                count: 0
            };
        }
        hospitalStats[patient.hospital].totalRisk += calculateRiskScore(patient);
        hospitalStats[patient.hospital].count++;
    });
    
    const hospitalLabels = Object.keys(hospitalStats);
    const hospitalScores = hospitalLabels.map(hospital => 
        hospitalStats[hospital].totalRisk / hospitalStats[hospital].count
    );
    
    new Chart(ctx.getContext('2d'), {
        type: 'horizontalBar',
        data: {
            labels: hospitalLabels.map(name => name.replace('Hospital', '').replace('Healthcare', '').trim()),
            datasets: [{
                label: 'Average Risk Score',
                data: hospitalScores,
                backgroundColor: '#4ECDC4',
                borderColor: '#26A69A',
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Average Risk: ${context.parsed.x.toFixed(1)}%`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    beginAtZero: true,
                    max: 100,
                    grid: {
                        color: '#f0f0f0'
                    }
                },
                y: {
                    grid: {
                        display: false
                    }
                }
            },
            animation: {
                duration: 2000,
                easing: 'easeInOutQuart'
            }
        }
    });
}

// Create age vs risk correlation chart
function createAgeRiskCorrelationChart() {
    const ctx = document.getElementById('ageRiskCorrelationChart');
    if (!ctx) return;
    
    // Create scatter plot data
    const scatterData = patientsData.map(patient => ({
        x: patient.age,
        y: calculateRiskScore(patient)
    }));
    
    new Chart(ctx.getContext('2d'), {
        type: 'scatter',
        data: {
            datasets: [{
                label: 'Age vs Risk Score',
                data: scatterData,
                backgroundColor: 'rgba(78, 205, 196, 0.6)',
                borderColor: '#4ECDC4',
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return `Age: ${context.parsed.x}, Risk: ${context.parsed.y.toFixed(1)}%`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Patient Age'
                    },
                    min: 18,
                    max: 85
                },
                y: {
                    title: {
                        display: true,
                        text: 'Risk Score (%)'
                    },
                    min: 0,
                    max: 100
                }
            },
            animation: {
                duration: 2000
            }
        }
    });
}

// Update statistics
function updateStatistics() {
    const totalPatients = filteredData.length;
    const normalResults = filteredData.filter(p => p.testResults === 'Normal').length;
    const avgCost = filteredData.reduce((sum, p) => sum + p.billingAmount, 0) / totalPatients;
    
    // Calculate accuracy (simulated)
    const accuracy = 94.2;
    
    // Update DOM elements
    updateStatElement('.stat-box:nth-child(1) .stat-value', totalPatients.toLocaleString());
    updateStatElement('.stat-box:nth-child(2) .stat-value', ((normalResults / totalPatients) * 100).toFixed(1) + '%');
    updateStatElement('.stat-box:nth-child(3) .stat-value', '₹' + (avgCost / 100000).toFixed(1) + 'L');
    updateStatElement('.stat-box:nth-child(4) .stat-value', accuracy.toFixed(1) + '%');
}

// Update statistic element
function updateStatElement(selector, value) {
    const element = document.querySelector(selector);
    if (element) {
        element.textContent = value;
    }
}

// View patient details
function viewPatientDetails(index) {
    const patient = filteredData[index];
    if (!patient) return;
    
    const riskScore = calculateRiskScore(patient);
    const riskLevel = getRiskLevel(riskScore);
    
    // Create modal content
    const modalContent = `
        <div class="modal fade" id="patientModal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Patient Details - ${patient.name}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Personal Information</h6>
                                <p><strong>Name:</strong> ${patient.name}</p>
                                <p><strong>Age:</strong> ${patient.age} years</p>
                                <p><strong>Gender:</strong> ${patient.gender}</p>
                                <p><strong>Blood Type:</strong> ${patient.bloodType}</p>
                            </div>
                            <div class="col-md-6">
                                <h6>Medical Information</h6>
                                <p><strong>Condition:</strong> ${patient.medicalCondition}</p>
                                <p><strong>Test Results:</strong> ${patient.testResults}</p>
                                <p><strong>Admission Type:</strong> ${patient.admissionType}</p>
                                <p><strong>Risk Score:</strong> ${Math.round(riskScore)}% (${riskLevel})</p>
                            </div>
                        </div>
                        <div class="row mt-3">
                            <div class="col-md-6">
                                <h6>Healthcare Details</h6>
                                <p><strong>Hospital:</strong> ${patient.hospital}</p>
                                <p><strong>Insurance:</strong> ${patient.insuranceProvider}</p>
                                <p><strong>Treatment Cost:</strong> ₹${patient.billingAmount.toLocaleString()}</p>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" onclick="generateReport(${index})">Generate Report</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal
    const existingModal = document.getElementById('patientModal');
    if (existingModal) {
        existingModal.remove();
    }
    
    // Add new modal
    document.body.insertAdjacentHTML('beforeend', modalContent);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('patientModal'));
    modal.show();
}

// Generate report
function generateReport(index) {
    const patient = filteredData[index];
    if (!patient) return;
    
    alert(`Generating comprehensive report for ${patient.name}...\nThis would typically create a PDF report with detailed analysis.`);
}

// Export data function
function exportData() {
    // Create CSV data
    const headers = ['ID', 'Name', 'Age', 'Gender', 'Condition', 'Test Results', 'Admission Type', 'Hospital', 'Insurance', 'Risk Score', 'Risk Level'];
    const csvData = [headers];
    
    filteredData.forEach((patient, index) => {
        const riskScore = calculateRiskScore(patient);
        const riskLevel = getRiskLevel(riskScore);
        
        csvData.push([
            index + 1,
            patient.name,
            patient.age,
            patient.gender,
            patient.medicalCondition,
            patient.testResults,
            patient.admissionType,
            patient.hospital,
            patient.insuranceProvider,
            Math.round(riskScore),
            riskLevel
        ]);
    });
    
    // Convert to CSV string
    const csvString = csvData.map(row => row.join(',')).join('\n');
    
    // Download CSV
    const blob = new Blob([csvString], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'healthcare_analytics_data.csv';
    a.click();
    window.URL.revokeObjectURL(url);
}

// Toggle chart type function
function toggleChartType(type) {
    // Update button states
    const buttons = document.querySelectorAll('.chart-controls .btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Recreate chart with new type
    if (type === 'line') {
        createRiskTrendsLineChart();
    } else {
        createRiskTrendsChart();
    }
}

// Create line version of risk trends chart
function createRiskTrendsLineChart() {
    const ctx = document.getElementById('riskTrendsChart');
    if (!ctx) return;
    
    // Clear existing chart
    Chart.getChart(ctx)?.destroy();
    
    // Create monthly trend data (simulated)
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];
    const lowRiskTrend = [65, 67, 63, 69, 71, 68];
    const moderateRiskTrend = [25, 23, 27, 22, 20, 24];
    const highRiskTrend = [10, 10, 10, 9, 9, 8];
    
    new Chart(ctx.getContext('2d'), {
        type: 'line',
        data: {
            labels: months,
            datasets: [
                {
                    label: 'Low Risk',
                    data: lowRiskTrend,
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    fill: true,
                    tension: 0.4
                },
                {
                    label: 'Moderate Risk',
                    data: moderateRiskTrend,
                    borderColor: '#ffc107',
                    backgroundColor: 'rgba(255, 193, 7, 0.1)',
                    fill: true,
                    tension: 0.4
                },
                {
                    label: 'High Risk',
                    data: highRiskTrend,
                    borderColor: '#dc3545',
                    backgroundColor: 'rgba(220, 53, 69, 0.1)',
                    fill: true,
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: true,
                    position: 'top'
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    title: {
                        display: true,
                        text: 'Percentage (%)'
                    }
                }
            },
            animation: {
                duration: 1500
            }
        }
    });
}